<!DOCTYPE html>
<html>
<head>
    <title>Tuition System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #fff0f6;
        }
        .navbar {
            background-color: #ff69b4;
        }
        .navbar-brand, .nav-link {
            color: white !important;
            font-weight: bold;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
        }
        .btn-pink:hover {
            background-color: #ff85c2;
        }
        .card {
            border-radius: 15px;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#">💗 Tuition System</a>
        <div>
            <a href="../auth/logout.php" class="nav-link d-inline">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
