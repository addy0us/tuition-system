<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =====================
   ADD SUBJECT
===================== */
if (isset($_POST['add_subject'])) {
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: subject.php");
        exit;
    }
    
    $subject_name  = trim($_POST['subject_name']);
    $subject_level = trim($_POST['subject_level']);

    if ($subject_name === "" || $subject_level === "") {
        $_SESSION['error_message'] = "All fields are required.";
    } else {
        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO subject (subject_name, subject_level) VALUES (?, ?)"
        );
        mysqli_stmt_bind_param($stmt, "ss", $subject_name, $subject_level);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success_message'] = "✅ Subject added successfully!";
        } else {
            $_SESSION['error_message'] = "❌ Failed to add subject. Please try again.";
        }
        
        mysqli_stmt_close($stmt);
        header("Location: subject.php");
        exit;
    }
}

$result = mysqli_query(
    $conn,
    "SELECT * FROM subject ORDER BY subject_id ASC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Subject Management</title>

<style>
/* ===== BASE ===== */
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(
        180deg,
        #dbeff0 0%,
        #eef7f7 45%,
        #f7fcfc 100%
    );
    color: #2f3e46;
}

/* ===== NAVBAR ===== */
.navbar {
    background: #2f5f63;
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #fff;
}

.logo {
    font-size: 22px;
    font-weight: 600;
}

nav a {
    color: #fff;
    text-decoration: none;
    margin-left: 20px;
    font-weight: 500;
}

nav a.logout {
    background: #1e4246;
    padding: 8px 16px;
    border-radius: 20px;
}

/* ===== CONTAINER ===== */
.container {
    max-width: 1100px;
    margin: 40px auto;
    padding: 0 20px;
}

/* ===== ALERT MESSAGES ===== */
.alert {
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    font-weight: 500;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-danger {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.alert .close-btn {
    background: none;
    border: none;
    font-size: 20px;
    cursor: pointer;
    color: inherit;
    padding: 0;
    margin-left: 15px;
}

/* ===== CARD ===== */
.card {
    background: #fff;
    border-radius: 26px;
    padding: 35px;
    margin-bottom: 30px;
    box-shadow: 0 18px 40px rgba(0,0,0,0.08);
}

.card h3 {
    margin-top: 0;
    margin-bottom: 20px;
}

/* ===== ADD SUBJECT FORM ===== */
.subject-form {
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
}

.subject-form input,
.subject-form select {
    height: 46px;
    padding: 0 16px;
    border-radius: 22px;
    border: 1px solid #ccc;
    font-size: 14px;
    flex: 1;
    min-width: 220px;
    font-family: 'Poppins', sans-serif;
}

.subject-form button {
    height: 46px;
    padding: 0 28px;
    border-radius: 24px;
    border: none;
    background: #2f3e46;
    color: #fff;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
}

.subject-form button:hover {
    background: #1f2a30;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

/* ===== TABLE ===== */
table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 14px;
    text-align: left;
}

th {
    background: #e6f1f2;
}

tr:not(:last-child) {
    border-bottom: 1px solid #ddd;
}

/* ===== BUTTONS ===== */
.btn-sm {
    display: inline-block;
    padding: 8px 18px;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 500;
    text-decoration: none;
    color: white;
    border: none;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
}

.btn-sm:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.btn-warning { 
    background: #f39c12;
}

.btn-warning:hover {
    background: #e67e22;
}

.btn-danger {
    background: #e74c3c;
}

.btn-danger:hover {
    background: #c0392b;
}

button.btn-sm {
    font-family: 'Poppins', sans-serif;
}

/* ===== FOOTER ===== */
footer {
    margin-top: 60px;
    padding: 40px;
    text-align: center;
    color: #555;
}

</style>
</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <h2>📚 Subject Management</h2>

    <!-- SUCCESS MESSAGE -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <span><?= htmlspecialchars($_SESSION['success_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- ERROR MESSAGE -->
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger">
            <span><?= htmlspecialchars($_SESSION['error_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <!-- ADD SUBJECT -->
    <div class="card">
        <h3>Add a Subject</h3>

        <form method="POST" class="subject-form">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <input
                type="text"
                name="subject_name"
                placeholder="Subject name"
                required
            >

            <select name="subject_level" required>
                <option value="">Select level</option>
                <option value="Primary">Primary</option>
                <option value="Secondary">Secondary</option>
                <option value="SPM">SPM</option>
            </select>

            <button type="submit" name="add_subject">
                Add Subject
            </button>
        </form>
    </div>

    <!-- SUBJECT LIST -->
    <div class="card">
        <h3>List of Subjects</h3>

        <table>
            <tr>
                <th>ID</th>
                <th>Subject Name</th>
                <th>Level</th>
                <th>Actions</th>
            </tr>

            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $row['subject_id'] ?></td>
                    <td><?= htmlspecialchars($row['subject_name']) ?></td>
                    <td><?= htmlspecialchars($row['subject_level']) ?></td>
                    <td>
                        <a href="edit_subject.php?id=<?= $row['subject_id'] ?>"
                           class="btn-sm btn-warning">Edit</a>

                        <form method="POST" action="delete_subject.php" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="id" value="<?= $row['subject_id'] ?>">
                            <button type="submit" class="btn-sm btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this subject?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align:center;">No subjects found</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>