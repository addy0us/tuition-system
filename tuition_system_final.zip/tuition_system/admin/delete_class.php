<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error_message'] = "Invalid request. Please try again.";
    header("Location: class.php");
    exit;
}

$class_id = (int) $_POST['id'];

// Check if class has bookings
$check_booking = mysqli_prepare($conn, "SELECT COUNT(*) as count FROM booking WHERE class_id = ?");
mysqli_stmt_bind_param($check_booking, "i", $class_id);
mysqli_stmt_execute($check_booking);
$result = mysqli_stmt_get_result($check_booking);
$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($check_booking);

if ($row['count'] > 0) {
    $_SESSION['error_message'] = "⚠️ Cannot delete this class! It has " . $row['count'] . " booking(s). Please delete those bookings first.";
    header("Location: class.php");
    exit;
}

// Check if class has schedules and delete them (schedules are safe to auto-delete)
$check_schedule = mysqli_prepare($conn, "SELECT COUNT(*) as count FROM schedule WHERE class_id = ?");
mysqli_stmt_bind_param($check_schedule, "i", $class_id);
mysqli_stmt_execute($check_schedule);
$result2 = mysqli_stmt_get_result($check_schedule);
$row2 = mysqli_fetch_assoc($result2);
mysqli_stmt_close($check_schedule);

if ($row2['count'] > 0) {
    // Delete schedules first (they're not critical data)
    $del_schedule = mysqli_prepare($conn, "DELETE FROM schedule WHERE class_id = ?");
    mysqli_stmt_bind_param($del_schedule, "i", $class_id);
    mysqli_stmt_execute($del_schedule);
    mysqli_stmt_close($del_schedule);
}

// Safe to delete class
$stmt = mysqli_prepare($conn, "DELETE FROM `class` WHERE class_id = ?");
mysqli_stmt_bind_param($stmt, "i", $class_id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success_message'] = "✅ Class deleted successfully!";
} else {
    $_SESSION['error_message'] = "❌ Failed to delete class. Please try again.";
}

mysqli_stmt_close($stmt);
header("Location: class.php");
exit;
?>