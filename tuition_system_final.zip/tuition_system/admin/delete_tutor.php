<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error_message'] = "Invalid request. Please try again.";
    header("Location: tutor.php");
    exit;
}

$id = (int) $_POST['id'];

// CHECK IF TUTOR HAS CLASSES FIRST
$check_stmt = mysqli_prepare($conn, "SELECT COUNT(*) as class_count FROM class WHERE tutor_id = ?");
mysqli_stmt_bind_param($check_stmt, "i", $id);
mysqli_stmt_execute($check_stmt);
$result = mysqli_stmt_get_result($check_stmt);
$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($check_stmt);

// If tutor has classes, don't allow deletion
if ($row['class_count'] > 0) {
    $_SESSION['error_message'] = "⚠️ Cannot delete this tutor! They are currently assigned to " . $row['class_count'] . " class(es). Please reassign or delete those classes first.";
    header("Location: tutor.php");
    exit;
}

// Safe to delete - tutor has no classes
$stmt = mysqli_prepare($conn, "DELETE FROM tutor WHERE tutor_id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success_message'] = "✅ Tutor deleted successfully!";
} else {
    $_SESSION['error_message'] = "❌ Failed to delete tutor. Please try again.";
}

mysqli_stmt_close($stmt);
header("Location: tutor.php");
exit;
?>