<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(
                180deg,
                #dbeff0 0%,
                #eef7f7 45%,
                #f7fcfc 100%
            );
        }

        /* NAVBAR */
        .navbar {
            background: #2f5f63;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        nav a.logout {
            background: #1e4246;
            padding: 8px 14px;
            border-radius: 20px;
        }

        /* CONTAINER */
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        /* ALERT MESSAGES */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert .close-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: inherit;
            padding: 0;
            margin-left: 15px;
        }

        /* CARD */
        .card {
            background: white;
            border-radius: 26px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        h2 {
            margin-bottom: 20px;
        }

        h3 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        /* TABS */
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #e6f1f2;
        }

        .tab {
            padding: 12px 24px;
            background: transparent;
            border: none;
            cursor: pointer;
            font-weight: 600;
            color: #666;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .tab.active {
            color: #2f5f63;
            border-bottom-color: #2f5f63;
        }

        .tab:hover {
            color: #2f5f63;
        }

        /* BUTTON */
        .btn {
            display: inline-block;
            padding: 10px 22px;
            background: #2f3e46;
            color: white;
            border-radius: 22px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #1f2a30;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .btn-success {
            background: #27ae60;
        }

        .btn-success:hover {
            background: #229954;
        }

        .btn-warning {
            background: #f39c12;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-sm {
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 500;
        }

        button.btn-sm {
            font-family: 'Poppins', sans-serif;
        }

        /* BADGE */
        .badge {
            padding: 6px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }

        .badge-approved {
            background: #d4edda;
            color: #155724;
        }

        .badge-rejected {
            background: #f8d7da;
            color: #721c24;
        }

        .badge-paid {
            background: #d1ecf1;
            color: #0c5460;
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px;
            text-align: left;
        }

        th {
            background: #e6f1f2;
        }

        tr:not(:last-child) {
            border-bottom: 1px solid #ddd;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            color: #444;
            background: #f7fbfb;
        }
    </style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <h2>📋 Booking Management</h2>

    <!-- SUCCESS MESSAGE -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <span><?= htmlspecialchars($_SESSION['success_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- ERROR MESSAGE -->
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger">
            <span><?= htmlspecialchars($_SESSION['error_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <!-- BOOKING LIST -->
    <div class="card">
        <div class="tabs">
            <button class="tab active" onclick="filterBookings('all')">All Bookings</button>
            <button class="tab" onclick="filterBookings('Pending')">Pending</button>
            <button class="tab" onclick="filterBookings('Approved')">Approved</button>
            <button class="tab" onclick="filterBookings('Rejected')">Rejected</button>
        </div>

        <table id="bookingTable">
            <tr>
                <th>ID</th>
                <th>Student</th>
                <th>Class</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Action</th>
            </tr>

            <?php
            $result = mysqli_query($conn, "
                SELECT 
                    b.booking_id,
                    b.booking_date,
                    b.booking_status,
                    b.payment_status,
                    s.name as student_name,
                    c.class_id,
                    sub.subject_name
                FROM booking b
                JOIN student s ON b.student_id = s.student_id
                JOIN class c ON b.class_id = c.class_id
                JOIN subject sub ON c.subject_id = sub.subject_id
                ORDER BY b.booking_id ASC
            ");
            
            while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr data-status="<?= $row['booking_status'] ?>">
                <td><?= $row['booking_id'] ?></td>
                <td><?= htmlspecialchars($row['student_name']) ?></td>
                <td>Class #<?= $row['class_id'] ?></td>
                <td><?= htmlspecialchars($row['subject_name']) ?></td>
                <td><?= htmlspecialchars($row['booking_date']) ?></td>
                <td>
                    <?php if ($row['booking_status'] === 'Pending'): ?>
                        <span class="badge badge-pending">Pending</span>
                    <?php elseif ($row['booking_status'] === 'Approved'): ?>
                        <span class="badge badge-approved">Approved</span>
                    <?php else: ?>
                        <span class="badge badge-rejected">Rejected</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($row['payment_status'] === 'Paid'): ?>
                        <span class="badge badge-paid">Paid</span>
                    <?php else: ?>
                        <span class="badge badge-pending">Pending</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($row['booking_status'] === 'Pending'): ?>
                        <form method="POST" action="approve_booking.php" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="id" value="<?= $row['booking_id'] ?>">
                            <button type="submit" class="btn btn-success btn-sm">
                                Approve
                            </button>
                        </form>

                        <form method="POST" action="reject_booking.php" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="id" value="<?= $row['booking_id'] ?>">
                            <button type="submit" class="btn btn-warning btn-sm">
                                Reject
                            </button>
                        </form>
                    <?php endif; ?>

                    <a href="edit_booking.php?id=<?= $row['booking_id'] ?>"
                       class="btn btn-warning btn-sm">Edit</a>

                    <form method="POST" action="delete_booking.php" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="id" value="<?= $row['booking_id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure you want to delete this booking?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

<script>
function filterBookings(status) {
    const rows = document.querySelectorAll('#bookingTable tr[data-status]');
    const tabs = document.querySelectorAll('.tab');
    
    // Update active tab
    tabs.forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter rows
    rows.forEach(row => {
        if (status === 'all' || row.dataset.status === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>

</body>
</html>