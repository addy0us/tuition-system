<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isset($_GET['id'])) {
    header("Location: subject.php");
    exit;
}

$subject_id = (int) $_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT subject_name, subject_level FROM subject WHERE subject_id=?");
mysqli_stmt_bind_param($stmt, "i", $subject_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    $_SESSION['error_message'] = "Subject not found.";
    header("Location: subject.php");
    exit;
}

$subject = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (isset($_POST['update_subject'])) {
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: edit_subject.php?id=$subject_id");
        exit;
    }
    
    $subject_name = ucwords(trim($_POST['subject_name']));
    $subject_level = trim($_POST['subject_level']);

    if ($subject_name == "" || $subject_level == "") {
        $_SESSION['error_message'] = "All fields are required.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE subject SET subject_name=?, subject_level=? WHERE subject_id=?");
        mysqli_stmt_bind_param($stmt, "ssi", $subject_name, $subject_level, $subject_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success_message'] = "✅ Subject updated successfully!";
            mysqli_stmt_close($stmt);
            header("Location: subject.php");
            exit;
        } else {
            $_SESSION['error_message'] = "❌ Failed to update subject.";
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Subject</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(180deg, #dbeff0, #eef7f7, #f7fcfc);
        }

        .navbar {
            background: #2f5f63;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            color: white;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }

        .logout {
            background: #1e4246;
            padding: 8px 16px;
            border-radius: 20px;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 30px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .card {
            background: white;
            border-radius: 26px;
            padding: 35px;
            box-shadow: 0 18px 40px rgba(0,0,0,.08);
        }

        h3 {
            margin-top: 0;
        }

        .subject-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .subject-form input,
        .subject-form select {
            height: 46px;
            padding: 0 16px;
            border-radius: 12px;
            border: 1px solid #ccc;
            font-family: 'Poppins', sans-serif;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #2f5f63;
            box-shadow: 0 0 0 3px rgba(47, 95, 99, 0.1);
        }

        .actions {
            margin-top: 25px;
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 12px 26px;
            border-radius: 24px;
            border: none;
            background: #2f3e46;
            color: white;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #1f2a30;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .btn-secondary {
            background: #6c757d;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            background: #f7fbfb;
        }
    </style>
</head>

<body>

<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="subject.php">Back to Subjects</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <div class="card">

        <h3>✏️ Edit Subject</h3>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($_SESSION['error_message']) ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="subject-form">

                <input type="text" name="subject_name"
                       value="<?= htmlspecialchars($subject['subject_name']) ?>"
                       placeholder="Subject Name" required>

                <select name="subject_level" required>
                    <option value="">Select Level</option>
                    <option value="Primary" <?= $subject['subject_level'] == "Primary" ? "selected" : "" ?>>Primary</option>
                    <option value="Secondary" <?= $subject['subject_level'] == "Secondary" ? "selected" : "" ?>>Secondary</option>
                    <option value="SPM" <?= $subject['subject_level'] == "SPM" ? "selected" : "" ?>>SPM</option>
                </select>

            </div>

            <div class="actions">
                <button type="submit" name="update_subject" class="btn">Save Changes</button>
                <a href="subject.php" class="btn btn-secondary">Cancel</a>
            </div>

        </form>

    </div>
</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>