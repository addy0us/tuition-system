<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error_message'] = "Invalid request. Please try again.";
    header("Location: student.php");
    exit;
}

$student_id = (int) $_POST['id'];

// Check if student has bookings
$check = mysqli_prepare($conn, "SELECT COUNT(*) as count FROM booking WHERE student_id = ?");
mysqli_stmt_bind_param($check, "i", $student_id);
mysqli_stmt_execute($check);
$result = mysqli_stmt_get_result($check);
$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($check);

if ($row['count'] > 0) {
    $_SESSION['error_message'] = "⚠️ Cannot delete this student! They have " . $row['count'] . " booking(s). Please delete those bookings first.";
    header("Location: student.php");
    exit;
}

// Get user_id before deleting student (to delete login account)
$get_user = mysqli_prepare($conn, "SELECT user_id FROM student WHERE student_id = ?");
mysqli_stmt_bind_param($get_user, "i", $student_id);
mysqli_stmt_execute($get_user);
$user_result = mysqli_stmt_get_result($get_user);
$user_data = mysqli_fetch_assoc($user_result);
$user_id = $user_data['user_id'] ?? null;
mysqli_stmt_close($get_user);

// Delete student
$stmt = mysqli_prepare($conn, "DELETE FROM student WHERE student_id = ?");
mysqli_stmt_bind_param($stmt, "i", $student_id);

if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    
    // Also delete the user account if exists
    if ($user_id) {
        $del_user = mysqli_prepare($conn, "DELETE FROM users WHERE user_id = ?");
        mysqli_stmt_bind_param($del_user, "i", $user_id);
        mysqli_stmt_execute($del_user);
        mysqli_stmt_close($del_user);
    }
    
    $_SESSION['success_message'] = "✅ Student deleted successfully!";
} else {
    $_SESSION['error_message'] = "❌ Failed to delete student. Please try again.";
}

header("Location: student.php");
exit;
?>