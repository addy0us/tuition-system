<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error_message'] = "Invalid request. Please try again.";
    header("Location: booking.php");
    exit;
}

$booking_id = intval($_POST['id']);

// Get booking details and class price
$stmt = mysqli_prepare($conn, "
    SELECT b.booking_id, b.booking_status
    FROM booking b
    INNER JOIN class c ON b.class_id = c.class_id
    WHERE b.booking_id = ?
");
mysqli_stmt_bind_param($stmt, "i", $booking_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$booking = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$booking) {
    $_SESSION['error_message'] = "Booking not found.";
    header("Location: booking.php");
    exit;
}

if ($booking['booking_status'] === 'Approved') {
    $_SESSION['error_message'] = "Booking is already approved.";
    header("Location: booking.php");
    exit;
}

// Approve booking
$update_stmt = mysqli_prepare($conn, "UPDATE booking SET booking_status = 'Approved' WHERE booking_id = ?");
mysqli_stmt_bind_param($update_stmt, "i", $booking_id);
mysqli_stmt_execute($update_stmt);
mysqli_stmt_close($update_stmt);

// Check if payment already exists
$check_stmt = mysqli_prepare($conn, "SELECT payment_id FROM payment WHERE booking_id = ?");
mysqli_stmt_bind_param($check_stmt, "i", $booking_id);
mysqli_stmt_execute($check_stmt);
$check_result = mysqli_stmt_get_result($check_stmt);
$payment_exists = mysqli_num_rows($check_result) > 0;
mysqli_stmt_close($check_stmt);

// Create payment record if it doesn't exist
if (!$payment_exists) {
    $class_price = $booking['class_price'] ?? 0;
    
    $insert_stmt = mysqli_prepare($conn, "
        INSERT INTO payment (booking_id, amount, payment_method, payment_status, payment_date)
        VALUES (?, ?, 'Pending', 'Pending', NULL)
    ");
    mysqli_stmt_bind_param($insert_stmt, "id", $booking_id, $class_price);
    mysqli_stmt_execute($insert_stmt);
    mysqli_stmt_close($insert_stmt);
}

$_SESSION['success_message'] = "✅ Booking approved successfully!";
header("Location: booking.php");
exit;
?>