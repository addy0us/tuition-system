<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

/* =====================
   ADD SCHEDULE
===================== */
if (isset($_POST['add_schedule'])) {
    mysqli_query($conn, "
        INSERT INTO schedule 
        (class_id, schedule_date, day_of_week, start_time, end_time)
        VALUES (
            '{$_POST['class_id']}',
            '{$_POST['schedule_date']}',
            '{$_POST['day_of_week']}',
            '{$_POST['start_time']}',
            '{$_POST['end_time']}'
        )
    ");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Class Schedule</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(
                180deg,
                #dbeff0 0%,
                #eef7f7 45%,
                #f7fcfc 100%
            );
            color: #2f3e46;
        }

        /* NAVBAR */
        .navbar {
            background: #2f5f63;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        nav a.logout {
            background: #1e4246;
            padding: 8px 14px;
            border-radius: 20px;
        }

        /* CONTAINER */
        .container {
            max-width: 1100px;
            margin: 40px auto;
        }

        h2 {
            margin-bottom: 20px;
        }

        /* CARD */
        .card {
            background: white;
            border-radius: 26px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        /* FORM GRID */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #ccc;
        }

        .btn {
            padding: 10px 24px;
            background: #2f3e46;
            color: white;
            border-radius: 24px;
            border: none;
            font-weight: 600;
            cursor: pointer;
        }

        .btn:hover {
            background: #1f2a30;
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px;
            text-align: left;
        }

        th {
            background: #e6f1f2;
        }

        tr:not(:last-child) {
            border-bottom: 1px solid #ddd;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            color: #444;
            background: #f7fbfb;
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <h2>🗓 Tuition Class Schedule</h2>

    <!-- ADD SCHEDULE -->
    <div class="card">
        <h3>➕ Add Schedule</h3>

        <form method="POST">
            <div class="form-grid">

                <div>
                    <label>Class</label>
                    <select name="class_id" required>
                        <?php
                        $classes = mysqli_query($conn, "
                            SELECT c.class_id, s.subject_name
                            FROM class c
                            JOIN subject s ON c.subject_id = s.subject_id
                        ");
                        while ($c = mysqli_fetch_assoc($classes)) {
                            echo "<option value='{$c['class_id']}'>
                                    {$c['subject_name']}
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label>Date</label>
                    <input type="date" name="schedule_date" required>
                </div>

                <div>
                    <label>Day</label>
                    <select name="day_of_week" required>
                        <option>Monday</option>
                        <option>Tuesday</option>
                        <option>Wednesday</option>
                        <option>Thursday</option>
                        <option>Friday</option>
                    </select>
                </div>

                <div>
                    <label>Start Time</label>
                    <input type="time" name="start_time" required>
                </div>

                <div>
                    <label>End Time</label>
                    <input type="time" name="end_time" required>
                </div>

            </div>

            <br>
            <button type="submit" name="add_schedule" class="btn">
                Add Schedule
            </button>
        </form>
    </div>

    <!-- VIEW SCHEDULE -->
    <div class="card">
        <h3>📋 Weekly Schedule</h3>

        <table>
            <tr>
                <th>Subject</th>
                <th>Date</th>
                <th>Day</th>
                <th>Time</th>
            </tr>

            <?php
            $result = mysqli_query($conn, "
                SELECT sc.*, s.subject_name
                FROM schedule sc
                JOIN class c ON sc.class_id = c.class_id
                JOIN subject s ON c.subject_id = s.subject_id
                ORDER BY sc.schedule_date ASC
            ");

            while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= htmlspecialchars($row['subject_name']) ?></td>
                <td><?= $row['schedule_date'] ?></td>
                <td><?= $row['day_of_week'] ?></td>
                <td><?= $row['start_time'] ?> – <?= $row['end_time'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>
