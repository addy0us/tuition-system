<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   ADD CLASS
========================= */
if (isset($_POST['add'])) {

    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: class.php");
        exit;
    }

    $subject_id    = (int) $_POST['subject_id'];
    $tutor_id      = (int) $_POST['tutor_id'];
    $start_time    = trim($_POST['start_time']);
    $end_time      = trim($_POST['end_time']);
    $total_student = (int) $_POST['total_student'];

    $stmt = mysqli_prepare($conn,
        "INSERT INTO `class` (subject_id, tutor_id, start_time, end_time, total_student)
         VALUES (?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "iissi", $subject_id, $tutor_id, $start_time, $end_time, $total_student);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success_message'] = "✅ Class added successfully!";
    } else {
        $_SESSION['error_message'] = "❌ Failed to add class. Please try again.";
    }
    
    mysqli_stmt_close($stmt);
    header("Location: class.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Class Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(
                180deg,
                #dbeff0 0%,
                #eef7f7 45%,
                #f7fcfc 100%
            );
        }

        /* NAVBAR */
        .navbar {
            background: #2f5f63;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        nav a.logout {
            background: #1e4246;
            padding: 8px 14px;
            border-radius: 20px;
        }

        /* CONTAINER */
        .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 20px;
        }

        /* ALERT MESSAGES */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert .close-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: inherit;
            padding: 0;
            margin-left: 15px;
        }

        /* CARD */
        .card {
            background: white;
            border-radius: 26px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        h2 {
            margin-bottom: 20px;
        }

        h3 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        /* FORM */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .form-grid .full-width {
            grid-column: span 2;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-grid .full-width {
                grid-column: span 1;
            }
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        /* BUTTON */
        .btn {
            display: inline-block;
            padding: 10px 22px;
            background: #2f3e46;
            color: white;
            border-radius: 22px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #1f2a30;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .btn-warning {
            background: #f39c12;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-sm {
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 500;
        }

        button.btn-sm {
            font-family: 'Poppins', sans-serif;
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px;
            text-align: left;
        }

        th {
            background: #e6f1f2;
        }

        tr:not(:last-child) {
            border-bottom: 1px solid #ddd;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            color: #444;
            background: #f7fbfb;
        }
    </style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <h2>📖 Class Management</h2>

    <!-- SUCCESS MESSAGE -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <span><?= htmlspecialchars($_SESSION['success_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- ERROR MESSAGE -->
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger">
            <span><?= htmlspecialchars($_SESSION['error_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <!-- ADD CLASS -->
    <div class="card">
        <h3>Add New Class</h3>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-grid">

                <div>
                    <label>Subject</label>
                    <select name="subject_id" required>
                        <option value="">Select Subject</option>
                        <?php
                        $subjects = mysqli_query($conn, "SELECT * FROM subject");
                        while ($s = mysqli_fetch_assoc($subjects)) {
                            echo "<option value='{$s['subject_id']}'>
                                    " . htmlspecialchars($s['subject_name']) . " ({$s['subject_level']})
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label>Tutor</label>
                    <select name="tutor_id" required>
                        <option value="">Select Tutor</option>
                        <?php
                        $tutors = mysqli_query($conn, "SELECT * FROM tutor");
                        while ($t = mysqli_fetch_assoc($tutors)) {
                            echo "<option value='{$t['tutor_id']}'>
                                    " . htmlspecialchars($t['tutor_name']) . "
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label>Start Time</label>
                    <input type="time" name="start_time" required>
                </div>

                <div>
                    <label>End Time</label>
                    <input type="time" name="end_time" required>
                </div>

                <div class="full-width">
                    <label>Total Students (Capacity)</label>
                    <input type="number" name="total_student" min="1" required>
                </div>

            </div>

            <br>
            <button type="submit" name="add" class="btn">
                Add Class
            </button>
        </form>
    </div>

    <!-- CLASS LIST -->
    <div class="card">
        <h3>Class List</h3>

        <table>
            <tr>
                <th>ID</th>
                <th>Subject</th>
                <th>Tutor</th>
                <th>Time</th>
                <th>Capacity</th>
                <th>Action</th>
            </tr>

            <?php
            $result = mysqli_query($conn, "
                SELECT 
                    c.class_id,
                    c.start_time,
                    c.end_time,
                    c.total_student,
                    s.subject_name,
                    t.tutor_name
                FROM `class` c
                LEFT JOIN subject s ON c.subject_id = s.subject_id
                LEFT JOIN tutor t ON c.tutor_id = t.tutor_id
                ORDER BY c.class_id DESC
            ");
            
            while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= $row['class_id'] ?></td>
                <td><?= htmlspecialchars($row['subject_name']) ?></td>
                <td><?= htmlspecialchars($row['tutor_name']) ?></td>
                <td><?= htmlspecialchars($row['start_time']) ?> - <?= htmlspecialchars($row['end_time']) ?></td>
                <td><?= $row['total_student'] ?> students</td>
                <td>
                    <a href="edit_class.php?id=<?= $row['class_id'] ?>"
                       class="btn btn-warning btn-sm">Edit</a>

                    <form method="POST" action="delete_class.php" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="id" value="<?= $row['class_id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure you want to delete this class?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>