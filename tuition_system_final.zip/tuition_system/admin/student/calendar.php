<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>My Class Schedule</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<!-- FullCalendar -->
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>

<style>

body{
margin:0;
font-family:Poppins,sans-serif;
background:linear-gradient(180deg,#83c2c5 20%,#eef5f5 100%);
}

.navbar{
background:#2f5f63;
padding:18px 40px;
display:flex;
justify-content:space-between;
color:white;
}

nav a{
color:white;
text-decoration:none;
margin-left:20px;
}

.container{
max-width:900px;
margin:60px auto;
background:white;
padding:30px;
border-radius:26px;
box-shadow:0 18px 40px rgba(0,0,0,.08);
}

footer{
margin-top:80px;
padding:40px;
text-align:center;
color:#555;
}

</style>
</head>

<body>

<header class="navbar">
<div>Tuition System</div>
<nav>
<a href="dashboard.php">Dashboard</a>
<a href="../auth/logout.php">Logout</a>
</nav>
</header>

<div class="container">

<h2>📅 My Class Schedule</h2>

<div id="calendar"></div>

</div>

<footer>
© <?= date("Y") ?> Tuition System · Student Dashboard
</footer>

<script>

document.addEventListener('DOMContentLoaded', function () {

    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 600,
        events: 'fetch_schedule.php'
    });

    calendar.render();

});
</script>

</body>
</html>
