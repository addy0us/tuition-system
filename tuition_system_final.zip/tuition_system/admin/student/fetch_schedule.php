<?php
session_start();
require_once "../config/db.php";

$student_id = $_SESSION['user_id'];

$result = mysqli_query($conn,"
SELECT 
    b.booking_date,
    sub.subject_name
FROM booking b
JOIN class c ON b.class_id=c.class_id
JOIN subject sub ON c.subject_id=sub.subject_id
WHERE b.booking_status='Approved'
AND b.student_id=$student_id
");

$events = [];

while($row=mysqli_fetch_assoc($result)){
    $events[] = [
        "title" => $row['subject_name'],
        "start" => $row['booking_date']
    ];
}

echo json_encode($events);
