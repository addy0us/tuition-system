<?php
session_start();
require_once "../config/db.php";

if ($_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

include("../includes/header.php");

// Get student_id
$res = mysqli_query($conn,
    "SELECT student_id FROM student WHERE user_id = '{$_SESSION['user_id']}'"
);
$student = mysqli_fetch_assoc($res);
$student_id = $student['student_id'];
?>

<h3 class="mb-4">📅 My Schedule</h3>

<div class="card shadow p-4">
<table class="table table-bordered table-striped bg-white">
    <tr>
        <th>Subject</th>
        <th>Date</th>
        <th>Day</th>
        <th>Time</th>
    </tr>

<?php
$result = mysqli_query($conn,
    "SELECT sc.*, s.subject_name
     FROM booking b
     JOIN class c ON b.class_id = c.class_id
     JOIN subject s ON c.subject_id = s.subject_id
     JOIN schedule sc ON sc.class_id = c.class_id
     WHERE b.student_id = '$student_id'"
);

while ($row = mysqli_fetch_assoc($result)) {
?>
<tr>
    <td><?= $row['subject_name'] ?></td>
    <td><?= $row['schedule_date'] ?></td>
    <td><?= $row['day_of_week'] ?></td>
    <td><?= $row['start_time'] ?> - <?= $row['end_time'] ?></td>
</tr>
<?php } ?>
</table>
</div>

<a href="dashboard.php" class="btn btn-secondary btn-sm mt-3">← Back</a>

<?php include("../includes/footer.php"); ?>
