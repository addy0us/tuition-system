<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn,"
SELECT student_id, name, email, phone_number, address, birth_date
FROM student
WHERE user_id=?
");

mysqli_stmt_bind_param($stmt,"i",$user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if(!$student){
    die("Student profile not found.");
}

?>
<!DOCTYPE html>
<html>
<head>
<title>My Profile</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<style>
body{
margin:0;
font-family:Poppins,sans-serif;
background:linear-gradient(180deg,#dbeff0,#eef7f7,#f7fcfc);
}
.container{
max-width:600px;
margin:80px auto;
background:white;
padding:40px;
border-radius:26px;
box-shadow:0 15px 35px rgba(0,0,0,.08);
}
h2{margin-top:0}
.info{
margin:15px 0;
padding:12px;
background:#f1f6f6;
border-radius:14px;
font-weight:600;
}
.btn{
display:inline-block;
margin-top:25px;
padding:10px 22px;
background:#2f3e46;
color:white;
border-radius:20px;
text-decoration:none;
}
</style>
</head>
<body>

<div class="container">
<h2>My Profile</h2>

<div class="info"><b>Name:</b> <?= htmlspecialchars($student['name']) ?></div>
<div class="info"><b>Email:</b> <?= htmlspecialchars($student['email']) ?></div>
<div class="info"><b>Phone:</b> <?= htmlspecialchars($student['phone_number']) ?></div>
<div class="info"><b>Address:</b> <?= htmlspecialchars($student['address']) ?></div>
<div class="info"><b>Birth Date:</b> <?= htmlspecialchars($student['birth_date']) ?></div>

<a href="dashboard.php" class="btn">Back to Dashboard</a>

</div>

</body>
</html>
