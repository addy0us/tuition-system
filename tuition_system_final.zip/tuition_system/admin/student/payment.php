<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* Get student_id */
$s = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT student_id FROM student WHERE user_id=$user_id
"));

$student_id = $s['student_id'];

/* Fetch approved bookings + payments */
$result = mysqli_query($conn,"
SELECT 
b.booking_date,
sub.subject_name,
p.payment_id,
p.payment_status,
p.payment_date
FROM booking b
JOIN payment p ON b.booking_id=p.booking_id
JOIN class c ON b.class_id=c.class_id
JOIN subject sub ON c.subject_id=sub.subject_id
WHERE b.student_id=$student_id
AND b.booking_status='Approved'
ORDER BY b.booking_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Payments</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<style>

body{
margin:0;
font-family:Poppins,sans-serif;
background:linear-gradient(180deg,#dbeff0,#eef7f7,#f7fcfc);
}

.navbar{
background:#2f5f63;
padding:18px 40px;
display:flex;
justify-content:space-between;
color:white;
}

nav a{
color:white;
text-decoration:none;
margin-left:20px;
}

.logout{
background:#1e4246;
padding:8px 14px;
border-radius:20px;
}

.container{
max-width:1000px;
margin:70px auto;
background:white;
padding:30px;
border-radius:26px;
box-shadow:0 15px 35px rgba(0,0,0,.08);
}

.header-row{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
}

.back-btn{
background:#6c757d;
color:white;
padding:10px 20px;
border-radius:20px;
text-decoration:none;
font-size:14px;
font-weight:500;
display:inline-flex;
align-items:center;
gap:8px;
transition:background 0.3s;
}

.back-btn:hover{
background:#5a6268;
}

table{
width:100%;
border-collapse:collapse;
}

th,td{
padding:14px;
text-align:left;
}

th{
background:#e6f1f2;
}

tr:not(:last-child){
border-bottom:1px solid #ddd;
}

.badge{
padding:6px 12px;
border-radius:12px;
font-size:12px;
font-weight:600;
}

.pending{background:#f1c40f;color:#333}
.paid{background:#2ecc71;color:white}

.btn{
padding:8px 18px;
border-radius:20px;
font-size:13px;
text-decoration:none;
color:white;
font-weight:600;
background:#2f3e46;
}

.btn:hover{background:#1f2a30}

footer{
margin-top:60px;
padding:40px;
text-align:center;
color:#555;
}

</style>
</head>

<body>

<header class="navbar">
<div>Tuition System</div>
<nav>
<a href="dashboard.php">Dashboard</a>
<a href="../auth/logout.php" class="logout">Logout</a>
</nav>
</header>

<div class="container">

<div class="header-row">
<h2>💳 My Payments</h2>
<a href="dashboard.php" class="back-btn">
← Back to Dashboard
</a>
</div>

<table>

<tr>
<th>Date</th>
<th>Subject</th>
<th>Status</th>
<th>Paid On</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)): ?>

<tr>

<td><?= $row['booking_date'] ?></td>
<td><?= htmlspecialchars($row['subject_name']) ?></td>

<td>
<?php if($row['payment_status']=="Paid"): ?>
<span class="badge paid">Paid</span>
<?php else: ?>
<span class="badge pending">Pending</span>
<?php endif; ?>
</td>

<td>
<?= $row['payment_date'] ? $row['payment_date'] : "-" ?>
</td>

<td>
<?php if($row['payment_status']=="Pending"): ?>
<a href="pay_now.php?id=<?= $row['payment_id']?>" class="btn">Pay Now</a>
<?php else: ?>
<span style="color:#777">Completed</span>
<?php endif; ?>
</td>

</tr>

<?php endwhile; ?>

</table>

</div>

<footer>
© <?= date("Y") ?> Tuition System · Student Dashboard
</footer>

</body>
</html>