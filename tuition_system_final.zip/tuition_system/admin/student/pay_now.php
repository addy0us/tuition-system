<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

$payment_id = intval($_GET['id']);

/* Get booking id */
$row = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT booking_id FROM payment WHERE payment_id=$payment_id
"));

$booking_id = $row['booking_id'];

/* Update payment */
mysqli_query($conn,"
UPDATE payment 
SET payment_status='Paid',
payment_method='Online',
payment_date=NOW()
WHERE payment_id=$payment_id
");

/* Update booking */
mysqli_query($conn,"
UPDATE booking 
SET payment_status='Paid'
WHERE booking_id=$booking_id
");

header("Location: payment.php");
exit;
