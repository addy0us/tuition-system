<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   ADD STUDENT
========================= */
if (isset($_POST['add'])) {

    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: student.php");
        exit;
    }

    $name         = trim($_POST['name']);
    $email        = trim($_POST['email']);
    $phone_number = trim($_POST['phone_number']);
    $address      = trim($_POST['address']);
    $birth_date   = trim($_POST['birth_date']);
    
    // Check if email already exists in users table
    $check_email = mysqli_prepare($conn, "SELECT user_id FROM users WHERE email = ?");
    mysqli_stmt_bind_param($check_email, "s", $email);
    mysqli_stmt_execute($check_email);
    $result = mysqli_stmt_get_result($check_email);
    
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['error_message'] = "⚠️ This email is already registered in the system!";
        mysqli_stmt_close($check_email);
        header("Location: student.php");
        exit;
    }
    mysqli_stmt_close($check_email);
    
    // STEP 1: Create user account for login
    $default_password = "student123"; // Default password (student should change this later)
    $hashed_password = password_hash($default_password, PASSWORD_DEFAULT);
    $role = "student";
    
    $user_stmt = mysqli_prepare($conn, "INSERT INTO users (email, password, role) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($user_stmt, "sss", $email, $hashed_password, $role);
    
    if (!mysqli_stmt_execute($user_stmt)) {
        $_SESSION['error_message'] = "❌ Failed to create user account.";
        mysqli_stmt_close($user_stmt);
        header("Location: student.php");
        exit;
    }
    
    // Get the newly created user_id
    $user_id = mysqli_insert_id($conn);
    mysqli_stmt_close($user_stmt);
    
    // STEP 2: Create student record linked to user account
    $stmt = mysqli_prepare($conn,
        "INSERT INTO student (name, email, phone_number, address, birth_date, user_id)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "sssssi", $name, $email, $phone_number, $address, $birth_date, $user_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success_message'] = "✅ Student added successfully! Login: $email | Password: $default_password";
    } else {
        // If student creation fails, delete the user account
        $delete_user = mysqli_prepare($conn, "DELETE FROM users WHERE user_id = ?");
        mysqli_stmt_bind_param($delete_user, "i", $user_id);
        mysqli_stmt_execute($delete_user);
        mysqli_stmt_close($delete_user);
        
        $_SESSION['error_message'] = "❌ Failed to add student. Please try again.";
    }
    
    mysqli_stmt_close($stmt);
    header("Location: student.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(
                180deg,
                #dbeff0 0%,
                #eef7f7 45%,
                #f7fcfc 100%
            );
        }

        /* NAVBAR */
        .navbar {
            background: #2f5f63;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        nav a.logout {
            background: #1e4246;
            padding: 8px 14px;
            border-radius: 20px;
        }

        /* CONTAINER */
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        /* ALERT MESSAGES */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert .close-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: inherit;
            padding: 0;
            margin-left: 15px;
        }

        /* INFO BOX */
        .info-box {
            background: #d1ecf1;
            color: #0c5460;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            border-left: 4px solid #17a2b8;
        }

        /* CARD */
        .card {
            background: white;
            border-radius: 26px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        h2 {
            margin-bottom: 20px;
        }

        h3 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        /* FORM */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .form-grid .full-width {
            grid-column: span 2;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-grid .full-width {
                grid-column: span 1;
            }
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 10px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        /* BUTTON */
        .btn {
            display: inline-block;
            padding: 10px 22px;
            background: #2f3e46;
            color: white;
            border-radius: 22px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #1f2a30;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .btn-warning {
            background: #f39c12;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-sm {
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 500;
        }

        button.btn-sm {
            font-family: 'Poppins', sans-serif;
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px;
            text-align: left;
        }

        th {
            background: #e6f1f2;
        }

        tr:not(:last-child) {
            border-bottom: 1px solid #ddd;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            color: #444;
            background: #f7fbfb;
        }
    </style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <h2>👨‍🎓 Student Management</h2>

    <!-- INFO BOX -->
    <div class="info-box">
        <strong>📌 Note:</strong> When you add a student, a login account is automatically created using their email.
        <br><strong>Default Password:</strong> student123 (Students should change this after first login)
    </div>

    <!-- SUCCESS MESSAGE -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <span><?= htmlspecialchars($_SESSION['success_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- ERROR MESSAGE -->
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger">
            <span><?= htmlspecialchars($_SESSION['error_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <!-- ADD STUDENT -->
    <div class="card">
        <h3>Add New Student</h3>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-grid">

                <div>
                    <label>Full Name</label>
                    <input type="text" name="name" required>
                </div>

                <div>
                    <label>Email (Will be used for login)</label>
                    <input type="email" name="email" required>
                </div>

                <div>
                    <label>Phone Number</label>
                    <input type="text" name="phone_number" required>
                </div>

                <div>
                    <label>Date of Birth</label>
                    <input type="date" name="birth_date" required>
                </div>

                <div class="full-width">
                    <label>Address</label>
                    <textarea name="address" required></textarea>
                </div>

            </div>

            <br>
            <button type="submit" name="add" class="btn">
                Add Student & Create Login
            </button>
        </form>
    </div>

    <!-- STUDENT LIST -->
    <div class="card">
        <h3>Student List</h3>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email (Login)</th>
                <th>Phone</th>
                <th>Birth Date</th>
                <th>Has Login</th>
                <th>Action</th>
            </tr>

            <?php
            $result = mysqli_query($conn, "SELECT * FROM student ORDER BY student_id ASC");
            while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= $row['student_id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['phone_number']) ?></td>
                <td><?= htmlspecialchars($row['birth_date']) ?></td>
                <td>
                    <?php if ($row['user_id']): ?>
                        <span style="color: green;">✅ Yes</span>
                    <?php else: ?>
                        <span style="color: orange;">⚠️ No</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="edit_student.php?id=<?= $row['student_id'] ?>"
                       class="btn btn-warning btn-sm">Edit</a>

                    <form method="POST" action="delete_student.php" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="id" value="<?= $row['student_id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure you want to delete this student?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>