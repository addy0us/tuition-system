<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error_message'] = "Invalid request. Please try again.";
    header("Location: booking.php");
    exit;
}

$booking_id = (int) $_POST['id'];

// Check if booking has payment and delete it first
$check = mysqli_prepare($conn, "SELECT payment_id FROM payment WHERE booking_id = ?");
mysqli_stmt_bind_param($check, "i", $booking_id);
mysqli_stmt_execute($check);
$result = mysqli_stmt_get_result($check);
$payment = mysqli_fetch_assoc($result);
mysqli_stmt_close($check);

// Delete payment first if exists
if ($payment) {
    $del_payment = mysqli_prepare($conn, "DELETE FROM payment WHERE booking_id = ?");
    mysqli_stmt_bind_param($del_payment, "i", $booking_id);
    mysqli_stmt_execute($del_payment);
    mysqli_stmt_close($del_payment);
}

// Now delete booking
$stmt = mysqli_prepare($conn, "DELETE FROM booking WHERE booking_id = ?");
mysqli_stmt_bind_param($stmt, "i", $booking_id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success_message'] = "✅ Booking deleted successfully!";
} else {
    $_SESSION['error_message'] = "❌ Failed to delete booking. Please try again.";
}

mysqli_stmt_close($stmt);
header("Location: booking.php");
exit;
?>