<?php
session_start();
require_once "../config/db.php";

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$booking_id = (int) $_GET['id'];

// 1️⃣ Get booking info
$stmt = mysqli_prepare(
    $conn,
    "SELECT class_id, booking_date
     FROM booking
     WHERE booking_id = ?"
);
mysqli_stmt_bind_param($stmt, "i", $booking_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$booking = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$booking) {
    die("Booking not found");
}

// 2️⃣ Update booking status
mysqli_query(
    $conn,
    "UPDATE booking
     SET booking_status = 'Approved'
     WHERE booking_id = $booking_id"
);

// 3️⃣ Auto create schedule
$day = date("l", strtotime($booking['booking_date']));

$stmt = mysqli_prepare(
    $conn,
    "INSERT INTO schedule
     (booking_id, class_id, schedule_date, day_of_week, start_time, end_time)
     VALUES (?, ?, ?, ?, '10:00', '12:00')"
);

mysqli_stmt_bind_param(
    $stmt,
    "iiss",
    $booking_id,
    $booking['class_id'],
    $booking['booking_date'],
    $day
);

mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

header("Location: booking.php");
exit;
