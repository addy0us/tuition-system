<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error_message'] = "Invalid request. Please try again.";
    header("Location: booking.php");
    exit;
}

$booking_id = intval($_POST['id']);

// Reject booking
$stmt = mysqli_prepare($conn, "UPDATE booking SET booking_status = 'Rejected' WHERE booking_id = ?");
mysqli_stmt_bind_param($stmt, "i", $booking_id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success_message'] = "✅ Booking rejected successfully!";
} else {
    $_SESSION['error_message'] = "❌ Failed to reject booking.";
}

mysqli_stmt_close($stmt);
header("Location: booking.php");
exit;
?>