<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

if(isset($_GET['id'])){

    $payment_id = intval($_GET['id']);

    // Get booking id
    $query = mysqli_query($conn,"SELECT booking_id FROM payment WHERE payment_id=$payment_id");
    $data = mysqli_fetch_assoc($query);

    if($data){

        $booking_id = $data['booking_id'];

        // Update payment
        mysqli_query($conn,"
            UPDATE payment 
            SET payment_status='Paid', 
                payment_date=NOW()
            WHERE payment_id=$payment_id
        ");

        // Update booking payment status
        mysqli_query($conn,"
            UPDATE booking 
            SET payment_status='Paid'
            WHERE booking_id=$booking_id
        ");
    }
}

header("Location: payment_management.php");
exit;
?>
