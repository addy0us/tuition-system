<?php
session_start();
require_once "../config/db.php";

/* Admin only */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ===== BASE ===== */
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(180deg, #83c2c5ff 20%, #eef5f5 100%);
    color: #2f3e46;
}

/* ===== NAVBAR ===== */
.navbar {
    background: rgba(47, 95, 99, 0.95);
    color: white;
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    font-size: 22px;
    font-weight: 600;
}

nav a {
    color: white;
    text-decoration: none;
    margin-left: 20px;
    font-weight: 500;
}

nav a.logout {
    background: #1e4246;
    padding: 8px 14px;
    border-radius: 20px;
}

/* ===== HERO WITH IMAGE + GRADIENT ===== */
.hero {
    max-width: 980px;
    margin: 38px auto;
    border-radius: 32px;
    padding: 70px;
    color: #ffffff;
     box-shadow: 0 20px 40px rgba(2, 64, 100, 0.30);

    background:
        linear-gradient(
            rgba(47, 95, 99, 0.85),
            rgba(47, 95, 99, 0.85)
        ),
        url("../assets/hero-bg.jpg");

    background-size: cover;
    background-position: center;

    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 50px;
    align-items: center;
}

.hero h1 {
    font-size: 42px;
    margin-bottom: 18px;
}

.hero p {
    font-size: 18px;
    line-height: 1.7;
    color: #ffffffff;
}

.hero .btn {
    background: #ffffff;
    color: #2f3e46;
}

.hero .btn:hover {
    background: #e1f1f1;
}

/* ===== HERO BOX ===== */
.hero-box {
    background:  rgba(47, 95, 99);
    border-radius: 26px;
    padding: 35px;
    color: #ffffffff;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}


/* ===== SECTIONS ===== */
.section {
    max-width: 1100px;
    margin: 60px auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 35px;
}

/* ===== CARDS ===== */
.card {
    background: #ffffff;
    border-radius: 28px;
    padding: 30px;
    box-shadow: 0 18px 40px rgba(0,0,0,0.08);

    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.card h3 {
    margin-top: 0;
    font-size: 22px;
     color: #555;
}

.card p {
    line-height: 1.7;
    color: #555;
    flex-grow: 1;
}

/* ===== BUTTON ===== */
.btn {
    display: inline-block;
    margin-top: 25px;
    padding: 12px 28px;
    background: #2f3e46;
    color: white;
    text-decoration: none;
    border-radius: 30px;
    font-weight: 600;
    width: fit-content;
}

.btn:hover {
    background: #1f2a30;
}

footer {
    margin-top: 80px;
    padding: 30px 0;
    text-align: center;
    color: #5a6b6f;
    background: transparent; 
    bottom: 0; 
    width: 100%
}

</style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="booking.php">Bookings</a>
        <a href="admin_calendar.php">Schedule</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<!-- HERO -->
<section class="hero">
    <div>
        <h1>Hi, Admin!</h1>
        <p>
            Manage bookings, subjects, and class schedules with ease.
            This dashboard gives you a clear overview of the tuition system.
        </p>
        <a href="booking.php" class="btn">View Bookings</a>
    </div>

    <div class="hero-box">
        <h3>System Overview</h3>
        <p>
            ➡ Approve student bookings<br>
            ➡ Manage subjects and classes<br>
            ➡ View weekly schedules <br>
            ➡ Manage Student Lists 

        </p>
    </div>
</section>

<!-- CARDS -->
<section class="section">

    <div class="card">
        <h3>Booking Requests</h3>
        <p>
            Review student booking requests and approve or reject them
            based on availability.
        </p>
        <a href="booking.php" class="btn">Manage</a>
    </div>

    <div class="card">
        <h3>Subjects</h3>
        <p>
            Add new subjects, update existing ones, or remove unused subjects
            from the system.
        </p>
        <a href="subject.php" class="btn">Manage</a>
    </div>


    <div class="card">
        <h3>Classes </h3>
        <p>
            Add new subjects, update existing ones, or remove unused subjects
            from the system.
        </p>
        <a href="class.php" class="btn">View</a>
    </div>


    <div class="card">
        <h3>Schedule Calendar</h3>
        <p>
            View all scheduled classes in a clean calendar format for better
            planning.
        </p>
        <a href="calendar.php" class="btn">View Schedule</a>
    </div>

    <div class="card">
        <h3>List of Students</h3>
        <p>
            Manage all students registered under system and update student list. 
        </p>
        <a href="student.php" class="btn">View List</a>
    </div>

     <div class="card">
        <h3>Our Tutors</h3>
        <p>
            Manage all tutors registered under system and update tutor list. 
        </p>
        <a href="tutor.php" class="btn">View List</a>
    </div>

</section>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>
