<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   ADD TUTOR
========================= */
if (isset($_POST['add'])) {
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: tutor.php");
        exit;
    }

    $tutor_name  = trim($_POST['tutor_name']);
    $tutor_email = trim($_POST['tutor_email']);
    $tutor_num   = trim($_POST['tutor_num']);
    $tutor_subject = trim($_POST['tutor_subject']);
    $tutor_availability = trim($_POST['tutor_availability']);

    // Use prepared statement for security
    $stmt = mysqli_prepare($conn, 
        "INSERT INTO tutor (tutor_name, tutor_email, tutor_num, tutor_subject, tutor_availability)
         VALUES (?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "sssss", $tutor_name, $tutor_email, $tutor_num, $tutor_subject, $tutor_availability);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success_message'] = "Tutor added successfully!";
    } else {
        $_SESSION['error_message'] = "Failed to add tutor. Please try again.";
    }
    
    mysqli_stmt_close($stmt);
    header("Location: tutor.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tutor Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(
        180deg,
        #dbeff0 0%,
        #eef7f7 45%,
        #f7fcfc 100%
    );
        }

        /* NAVBAR */
        .navbar {
            background: #2f5f63;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        nav a.logout {
            background: #1e4246;
            padding: 8px 14px;
            border-radius: 20px;
        }

        /* CONTAINER */
        .container {
            max-width: 1100px;
            margin: 40px auto;
        }

        /* ALERT MESSAGES */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert .close-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: inherit;
            padding: 0;
            margin-left: 15px;
        }

        /* CARD */
        .card {
            background: white;
            border-radius: 26px;
            padding: 25.5px;
            margin-bottom: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        h2 {
            margin-bottom: 20px;
        }

        /* FORM */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .form-grid .full-width {
            grid-column: span 2;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-grid .full-width {
                grid-column: span 1;
            }
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        /* BUTTON */
.btn {
    display: inline-block;
    padding: 8px 20px;
    color: white;
    border-radius: 25px;  /* More rounded */
    text-decoration: none;
    font-weight: 600;
    border: none;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s ease;
    font-family: 'Poppins', sans-serif;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.btn-warning {
    background: #f39c12;  
}

.btn-warning:hover {
    background: #e67e22;
}

.btn-danger {
    background: #e74c3c;  
}

.btn-danger:hover {
    background: #c0392b;
}

.btn-sm {
    padding: 8px 18px;
    font-size: 13px;

}

button.btn {
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
}

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px;
            text-align: left;
        }

        th {
            background: #e6f1f2;
        }

        tr:not(:last-child) {
            border-bottom: 1px solid #ddd;
        }

         footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            color: #444;
            background: #f7fbfb;
        }

    </style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <h2>🎓 Tutor Management</h2>

    <!-- SUCCESS MESSAGE -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <span><?= htmlspecialchars($_SESSION['success_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- ERROR MESSAGE -->
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger">
            <span><?= htmlspecialchars($_SESSION['error_message']) ?></span>
            <button class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <!-- ADD TUTOR -->
    <div class="card">
        <h3>Add Tutor</h3>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-grid">

                <div>
                    <label>Tutor Name</label>
                    <input type="text" name="tutor_name" required>
                </div>

                <div>
                    <label>Email</label>
                    <input type="email" name="tutor_email" required>
                </div>

                <div>
                    <label>Phone Number</label>
                    <input type="text" name="tutor_num" required>
                </div>

                <div>
                    <label>Subject Expertise</label>
                    <select name="tutor_subject" required>
                        <option value="">Select Subject</option>
                        <?php
                        $subjects = mysqli_query($conn, "SELECT subject_name FROM subject");
                        while ($s = mysqli_fetch_assoc($subjects)) {
                            echo "<option value='" . htmlspecialchars($s['subject_name']) . "'>
                                    " . htmlspecialchars($s['subject_name']) . "
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="full-width">
                    <label>Availability</label>
                    <select name="tutor_availability" required>
                        <option value="">Select Availability</option>
                        <option>Monday - Friday</option>
                        <option>Monday, Wednesday, Friday</option>
                        <option>Tuesday & Thursday</option>
                        <option>Weekends</option>
                        <option>Flexible</option>
                    </select>
                </div>

            </div>

            <br>
            <button type="submit" name="add" class="btn">
                Add Tutor
            </button>
        </form>
    </div>

    <!-- TUTOR LIST -->
    <div class="card">
        <h3>Tutor List</h3>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Subject</th>
                <th>Availability</th>
                <th>Action</th>
            </tr>

            <?php
            $result = mysqli_query($conn, "SELECT * FROM tutor");
            while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= $row['tutor_id'] ?></td>
                <td><?= htmlspecialchars($row['tutor_name']) ?></td>
                <td><?= htmlspecialchars($row['tutor_email']) ?></td>
                <td><?= htmlspecialchars($row['tutor_num']) ?></td>
                <td><?= htmlspecialchars($row['tutor_subject']) ?></td>
                <td><?= htmlspecialchars($row['tutor_availability']) ?></td>
                <td>
                    <a href="edit_tutor.php?id=<?= $row['tutor_id'] ?>"
                       class="btn btn-warning btn-sm">Edit</a>

                    <form method="POST" action="delete_tutor.php" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="id" value="<?= $row['tutor_id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure you want to delete this tutor?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>