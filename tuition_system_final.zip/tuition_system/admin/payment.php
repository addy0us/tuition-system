<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$result = mysqli_query($conn, "
SELECT 
    p.payment_id,
    p.booking_id,
    p.amount,
    p.payment_method,
    p.payment_status,
    p.payment_date,
    st.name AS student_name,
    sub.subject_name
FROM payment p
JOIN booking b ON p.booking_id = b.booking_id
JOIN student st ON b.student_id = st.student_id
JOIN class c ON b.class_id = c.class_id
JOIN subject sub ON c.subject_id = sub.subject_id
WHERE b.booking_status = 'Approved'
ORDER BY p.payment_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Management</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<style>

body{
margin:0;
font-family:Poppins,sans-serif;
background:linear-gradient(180deg,#dbeff0,#eef7f7,#f7fcfc);
}

.navbar{
background:#2f5f63;
padding:18px 40px;
display:flex;
justify-content:space-between;
color:white;
}

nav a{
color:white;
text-decoration:none;
margin-left:20px;
}

.logout{
background:#1e4246;
padding:8px 14px;
border-radius:20px;
}

.container{
max-width:1100px;
margin:50px auto;
background:white;
padding:30px;
border-radius:26px;
box-shadow:0 15px 35px rgba(0,0,0,.08);
}

table{
width:100%;
border-collapse:collapse;
}

th,td{
padding:14px;
}

th{
background:#e6f1f2;
}

tr:not(:last-child){
border-bottom:1px solid #ddd;
}

.badge{
padding:6px 12px;
border-radius:12px;
font-size:12px;
font-weight:600;
}

.pending{background:#f1c40f;color:#333}
.paid{background:#2ecc71;color:white}

.btn{
padding:8px 16px;
border-radius:20px;
font-size:13px;
text-decoration:none;
color:white;
font-weight:600;
background:#2f3e46;
}

.btn:hover{background:#1f2a30}

footer{
margin-top:60px;
padding:40px;
text-align:center;
color:#555;
}

</style>
</head>

<body>

<header class="navbar">
<div>Tuition System</div>
<nav>
<a href="dashboard.php"><b>Back to Dashboard</b></a>
<a href="../auth/logout.php" class="logout"><b>Logout</b></a>
</nav>
</header>

<div class="container">

<h2>Payment Management</h2>

<table>

<tr>
<th>Student</th>
<th>Subject</th>
<th>Amount (RM)</th>
<th>Method</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)): ?>

<tr>

<td><?= htmlspecialchars($row['student_name']) ?></td>
<td><?= htmlspecialchars($row['subject_name']) ?></td>
<td><?= number_format($row['amount'],2) ?></td>
<td><?= $row['payment_method'] ?></td>

<td>
<?php if($row['payment_status']=="Pending"): ?>
<span class="badge pending">Pending</span>
<?php else: ?>
<span class="badge paid">Paid</span>
<?php endif; ?>
</td>

<td>
<?php if($row['payment_status']=="Pending"): ?>
<a href="mark_paid.php?id=<?= $row['payment_id']?>" class="btn">Mark Paid</a>
<?php else: ?>
<span style="color:#777">Completed</span>
<?php endif; ?>
</td>

</tr>

<?php endwhile; ?>

</table>

</div>

<footer>
© <?= date("Y") ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>
