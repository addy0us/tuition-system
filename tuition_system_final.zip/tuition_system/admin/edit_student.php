<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isset($_GET['id'])) {
    header("Location: student.php");
    exit;
}

$student_id = (int) $_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM student WHERE student_id=?");
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    $_SESSION['error_message'] = "Student not found.";
    header("Location: student.php");
    exit;
}

$student = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (isset($_POST['update'])) {
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: edit_student.php?id=$student_id");
        exit;
    }
    
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone_number = trim($_POST['phone_number']);
    $address = trim($_POST['address']);
    $birth_date = trim($_POST['birth_date']);
    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : null;

    if (empty($name) || empty($email) || empty($phone_number) || empty($address) || empty($birth_date)) {
        $_SESSION['error_message'] = "All fields are required.";
    } else {
        $stmt = mysqli_prepare($conn, 
            "UPDATE student SET name=?, email=?, phone_number=?, address=?, birth_date=?, user_id=? WHERE student_id=?"
        );
        mysqli_stmt_bind_param($stmt, "sssssii", $name, $email, $phone_number, $address, $birth_date, $user_id, $student_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success_message'] = "✅ Student updated successfully!";
            mysqli_stmt_close($stmt);
            header("Location: student.php");
            exit;
        } else {
            $_SESSION['error_message'] = "❌ Failed to update student.";
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(180deg, #dbeff0, #eef7f7, #f7fcfc);
        }

        .navbar {
            background: #2f5f63;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            color: white;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        .logout {
            background: #1e4246;
            padding: 8px 16px;
            border-radius: 20px;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 30px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .card {
            background: white;
            border-radius: 26px;
            padding: 35px;
            box-shadow: 0 18px 40px rgba(0,0,0,.08);
        }

        h3 {
            margin-top: 0;
            margin-bottom: 25px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-grid .full-width {
            grid-column: span 2;
        }

        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-grid .full-width {
                grid-column: span 1;
            }
        }

        label {
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            color: #2f3e46;
        }

        input, textarea {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: #2f5f63;
            box-shadow: 0 0 0 3px rgba(47, 95, 99, 0.1);
        }

        .actions {
            margin-top: 30px;
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 12px 30px;
            border-radius: 25px;
            border: none;
            background: #2f3e46;
            color: white;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #1f2a30;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .btn-secondary {
            background: #6c757d;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            background: #f7fbfb;
        }
    </style>
</head>

<body>

<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="student.php">Back to Students</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <div class="card">

        <h3>✏️ Edit Student</h3>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($_SESSION['error_message']) ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="form-grid">

                <div>
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>
                </div>

                <div>
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>
                </div>

                <div>
                    <label>Phone Number</label>
                    <input type="text" name="phone_number" value="<?= htmlspecialchars($student['phone_number']) ?>" required>
                </div>

                <div>
                    <label>Date of Birth</label>
                    <input type="date" name="birth_date" value="<?= htmlspecialchars($student['birth_date']) ?>" required>
                </div>

                <div>
                    <label>User ID (Optional)</label>
                    <input type="number" name="user_id" value="<?= htmlspecialchars($student['user_id'] ?? '') ?>" placeholder="Leave blank if no login account">
                </div>

                <div class="full-width">
                    <label>Address</label>
                    <textarea name="address" required><?= htmlspecialchars($student['address']) ?></textarea>
                </div>

            </div>

            <div class="actions">
                <button type="submit" name="update" class="btn">Save Changes</button>
                <a href="student.php" class="btn btn-secondary">Cancel</a>
            </div>

        </form>

    </div>
</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>