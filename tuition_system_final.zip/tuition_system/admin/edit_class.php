<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$class_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch class details
$stmt = mysqli_prepare($conn, "SELECT * FROM `class` WHERE class_id = ?");
mysqli_stmt_bind_param($stmt, "i", $class_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$class = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$class) {
    $_SESSION['error_message'] = "Class not found.";
    header("Location: class.php");
    exit;
}

/* =========================
   UPDATE CLASS
========================= */
if (isset($_POST['update'])) {

    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error_message'] = "Invalid request. Please try again.";
        header("Location: edit_class.php?id=$class_id");
        exit;
    }

    $subject_id    = (int) $_POST['subject_id'];
    $tutor_id      = (int) $_POST['tutor_id'];
    $start_time    = trim($_POST['start_time']);
    $end_time      = trim($_POST['end_time']);
    $total_student = (int) $_POST['total_student'];

    $stmt = mysqli_prepare($conn,
        "UPDATE `class` 
         SET subject_id = ?, tutor_id = ?, start_time = ?, end_time = ?, total_student = ?
         WHERE class_id = ?"
    );
    mysqli_stmt_bind_param($stmt, "iissii", $subject_id, $tutor_id, $start_time, $end_time, $total_student, $class_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success_message'] = "✅ Class updated successfully!";
        mysqli_stmt_close($stmt);
        header("Location: class.php");
        exit;
    } else {
        $_SESSION['error_message'] = "❌ Failed to update class. Please try again.";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Class</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(
                180deg,
                #dbeff0 0%,
                #eef7f7 45%,
                #f7fcfc 100%
            );
        }

        /* NAVBAR */
        .navbar {
            background: #2f5f63;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 600;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        nav a.logout {
            background: #1e4246;
            padding: 8px 14px;
            border-radius: 20px;
        }

        /* CONTAINER */
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        /* ALERT MESSAGES */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* CARD */
        .card {
            background: white;
            border-radius: 26px;
            padding: 35px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        h2 {
            margin-top: 0;
            margin-bottom: 25px;
        }

        /* FORM */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .form-grid .full-width {
            grid-column: span 2;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-grid .full-width {
                grid-column: span 1;
            }
        }

        label {
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            color: #2f3e46;
        }

        input, select {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid #ddd;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #2f5f63;
            box-shadow: 0 0 0 3px rgba(47, 95, 99, 0.1);
        }

        /* BUTTONS */
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            padding: 12px 30px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: #2f3e46;
            color: white;
        }

        .btn-primary:hover {
            background: #1f2a30;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        footer {
            margin-top: 80px;
            padding: 40px;
            text-align: center;
            color: #444;
        }
    </style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="class.php">Back to Classes</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="container">

    <div class="card">
        <h2>✏️ Edit Class</h2>

        <!-- ERROR MESSAGE -->
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($_SESSION['error_message']) ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-grid">

                <div>
                    <label>Subject</label>
                    <select name="subject_id" required>
                        <option value="">Select Subject</option>
                        <?php
                        $subjects = mysqli_query($conn, "SELECT * FROM subject");
                        while ($s = mysqli_fetch_assoc($subjects)) {
                            $selected = ($s['subject_id'] == $class['subject_id']) ? 'selected' : '';
                            echo "<option value='{$s['subject_id']}' $selected>
                                    " . htmlspecialchars($s['subject_name']) . " ({$s['subject_level']})
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label>Tutor</label>
                    <select name="tutor_id" required>
                        <option value="">Select Tutor</option>
                        <?php
                        $tutors = mysqli_query($conn, "SELECT * FROM tutor");
                        while ($t = mysqli_fetch_assoc($tutors)) {
                            $selected = ($t['tutor_id'] == $class['tutor_id']) ? 'selected' : '';
                            echo "<option value='{$t['tutor_id']}' $selected>
                                    " . htmlspecialchars($t['tutor_name']) . "
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label>Start Time</label>
                    <input type="time" name="start_time" value="<?= htmlspecialchars($class['start_time']) ?>" required>
                </div>

                <div>
                    <label>End Time</label>
                    <input type="time" name="end_time" value="<?= htmlspecialchars($class['end_time']) ?>" required>
                </div>

                <div class="full-width">
                    <label>Total Students (Capacity)</label>
                    <input type="number" name="total_student" value="<?= htmlspecialchars($class['total_student']) ?>" min="1" required>
                </div>

            </div>

            <div class="btn-group">
                <button type="submit" name="update" class="btn btn-primary">
                    Update Class
                </button>
                <a href="class.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>

</body>
</html>