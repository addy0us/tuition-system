<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

/* ===== Handle Month & Date ===== */
$year  = $_GET['year']  ?? date('Y');
$month = $_GET['month'] ?? date('m');
$selected_date = $_GET['date'] ?? "$year-$month-" . date('d');

$first_day = strtotime("$year-$month-01");
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);

/* Prev / Next */
$prev_month = date("Y-m", strtotime("-1 month", $first_day));
$next_month = date("Y-m", strtotime("+1 month", $first_day));

/* Fetch approved + paid bookings for selected date */
$stmt = mysqli_prepare($conn, "
    SELECT 
        s.name AS student_name,
        sub.subject_name
    FROM booking b
    JOIN student s ON b.student_id = s.student_id
    JOIN class c ON b.class_id = c.class_id
    JOIN subject sub ON c.subject_id = sub.subject_id
    WHERE b.booking_status ='Approved'
      AND b.payment_status = 'Paid'
      AND b.booking_date = ?
");
mysqli_stmt_bind_param($stmt, "s", $selected_date);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Calendar</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
    
    body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(180deg, #83c2c5ff 20%, #eef5f5 100%);
    color: #2f3e46;

    }

     .navbar {
    background: rgba(47, 95, 99, 0.95);
    color: white;
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    }

    .logo {
    font-size: 22px;
    font-weight: 600;
    }

    nav a {
    color: white;
    text-decoration: none;
    margin-left: 20px;
    font-weight: 500;
    }

    nav a.logout {
    background: #1e4246;
    padding: 8px 14px;
    border-radius: 20px;
    }


        .calendar-card {
            max-width: 600px;
            margin: 50px auto 30px;
            background: white;
            border-radius: 28px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
        }

        .month-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .month-nav a {
            background: #e6f1f2;
            color: #2f3e46;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
        }

        .month {
            font-size: 20px;
            font-weight: 600;
        }

        .days, .dates {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
        }

        .days {
            font-weight: 600;
            color: #888;
        }

        .dates {
            margin-top: 15px;
        }

        .date {
            padding: 10px;
            border-radius: 50%;
            text-decoration: none;
            color: #2f3e46;
        }

        .date:hover {
            background: #e0f2f3;
        }

        .active {
            background: #3b82f6;
            color: white;
            font-weight: 600;
        }

        .details {
            max-width: 600px;
            margin: 0 auto 60px;
            background: white;
            border-radius: 26px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        }

        .event {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        .event:last-child { border-bottom: none; }
        .muted { color: #888; }

 footer {
    margin-top: 80px;
    padding: 30px 0;
    text-align: center;
    color: #5a6b6f;
    background: transparent; 
    bottom: 0; 
    width: 100%
}

        
    </style>
</head>

<body>

<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<div class="calendar-card">

    <div class="month-nav">
        <a href="?year=<?= substr($prev_month,0,4) ?>&month=<?= substr($prev_month,5,2) ?>">‹</a>
        <div class="month"><?= date("F Y", $first_day) ?></div>
        <a href="?year=<?= substr($next_month,0,4) ?>&month=<?= substr($next_month,5,2) ?>">›</a>
    </div>

    <div class="days">
        <div>Mon</div><div>Tue</div><div>Wed</div>
        <div>Thu</div><div>Fri</div><div>Sat</div><div>Sun</div>
    </div>

    <div class="dates">
        <?php
        for ($d = 1; $d <= $days_in_month; $d++) {
            $date = "$year-$month-" . str_pad($d, 2, '0', STR_PAD_LEFT);
            $active = ($date === $selected_date) ? 'active' : '';
            echo "<a class='date $active'
                  href='?year=$year&month=$month&date=$date'>$d</a>";
        }
        ?>
    </div>
</div>

<div class="details">
    <h3>📌 Schedule for <?= date("d M Y", strtotime($selected_date)) ?></h3>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <div class="event">
                <strong><?= htmlspecialchars($row['subject_name']) ?></strong><br>
                Student: <?= htmlspecialchars($row['student_name']) ?>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="muted">No approved bookings on this date.</p>
    <?php endif; ?>
</div>


<footer>
    © <?= date("Y"); ?> Tuition System · Admin Dashboard
</footer>


</body>
</html>
