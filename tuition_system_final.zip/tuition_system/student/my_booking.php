<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$s = mysqli_fetch_assoc(mysqli_query($conn,"SELECT student_id FROM student WHERE user_id=$user_id"));
$student_id = $s['student_id'];

$result = mysqli_query($conn,"
SELECT 
b.booking_id,
b.booking_date,
b.booking_status,
sub.subject_name
FROM booking b
JOIN class c ON b.class_id=c.class_id
JOIN subject sub ON c.subject_id=sub.subject_id
WHERE b.student_id=$student_id
ORDER BY b.booking_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Bookings</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<style>
body{margin:0;font-family:Poppins,sans-serif;background:linear-gradient(180deg,#dbeff0,#eef7f7,#f7fcfc);}
.navbar{background:#2f5f63;padding:18px 40px;display:flex;justify-content:space-between;color:white;}
nav a{color:white;text-decoration:none;margin-left:20px;}
.container{max-width:900px;margin:70px auto;background:white;padding:30px;border-radius:26px;box-shadow:0 18px 40px rgba(0,0,0,.08);}
table{width:100%;border-collapse:collapse;}
th,td{padding:14px;}
th{background:#e6f1f2;}
.badge{padding:6px 12px;border-radius:12px;font-size:12px;font-weight:600;text-decoration:none;display:inline-block;}
.pending{background:#f1c40f;color:#333}
.approved{background:#2ecc71;color:white}
.rejected{background:#e74c3c;color:white}
.paid{background:#3498db;color:white}
footer{margin-top:60px;padding:40px;text-align:center;color:#555;}
</style>
</head>

<body>

<header class="navbar">
<div>Tuition System</div>
<nav>
<a href="dashboard.php">Dashboard</a>
<a href="../auth/logout.php">Logout</a>
</nav>
</header>

<div class="container">

<h2>My Bookings</h2>

<table>
<tr>
<th>Subject</th>
<th>Date</th>
<th>Status</th>
<th>Payment</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)):

$payment = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT payment_status FROM payment WHERE booking_id=".$row['booking_id']
));

$isPaid = ($payment && $payment['payment_status']=='Paid');
?>

<tr>

<td><?= htmlspecialchars($row['subject_name']) ?></td>
<td><?= $row['booking_date'] ?></td>

<td>
<?php if($row['booking_status']=="Pending"): ?>
    <span class="badge pending">Pending</span>

<?php elseif($row['booking_status']=="Approved"): ?>
    <span class="badge approved">Approved</span>

<?php elseif($row['booking_status']=="Paid"): ?>
    <span class="badge paid">Paid</span>

<?php else: ?>
    <span class="badge rejected">Rejected</span>
<?php endif; ?>
</td>


<td>
<?php if($row['booking_status']=="Approved"): ?>
    <a href="pay_now.php?booking_id=<?= $row['booking_id']?>" class="badge pending">
        Pay Now
    </a>

<?php elseif($row['booking_status']=="Paid"): ?>
    <span class="badge paid">Paid</span>

<?php else: ?>
    —
<?php endif; ?>
</td>


</tr>

<?php endwhile; ?>

</table>

</div>

<footer>© <?= date("Y") ?> Tuition System</footer>

</body>
</html>
