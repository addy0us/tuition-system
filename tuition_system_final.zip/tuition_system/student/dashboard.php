<?php
session_start();
require_once "../config/db.php";

/* Admin only */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ===== BASE ===== */
html {
    min-height: 100%;
}

body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(
        180deg,
        #dbeff0 0%,
        #eef7f7 45%,
        #f7fcfc 100%
    );
    background-attachment: fixed; 
    color: #2f3e46;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* ===== NAVBAR ===== */
.navbar {
    background: rgba(47, 95, 99, 0.95);
    color: white;
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    font-size: 22px;
    font-weight: 600;
}

nav a {
    color: white;
    text-decoration: none;
    margin-left: 20px;
    font-weight: 500;
}

nav a.logout {
    background: #1e4246;
    padding: 8px 14px;
    border-radius: 20px;
}

/* ===== MAIN CONTENT WRAPPER ===== */
.main-content {
    flex: 1;
    padding-bottom: 40px;
}

/* ===== HERO WITH IMAGE + GRADIENT ===== */
.hero {
    max-width: 980px;
    margin: 38px auto;
    border-radius: 32px;
    padding: 70px;
    color: #ffffff;

    background:
        linear-gradient(
            rgba(47, 95, 99, 0.85),
            rgba(47, 95, 99, 0.85)
        ),
        url("../assets/hero-bg.jpg");

    background-size: cover;
    background-position: center;

    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 50px;
    align-items: center;
}

.hero h1 {
    font-size: 42px;
    margin-bottom: 18px;
}

.hero p {
    font-size: 18px;
    line-height: 1.7;
    color: #ffffffff;
}

.hero .btn {
    background: #ffffff;
    color: #2f3e46;
}

.hero .btn:hover {
    background: #e1f1f1;
}

/* ===== HERO BOX ===== */
.hero-box {
    background:  #2f3e46;
    border-radius: 26px;
    padding: 35px;
    color: #ffffffff;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}


/* ===== SECTIONS ===== */
.section {
    max-width: 1100px;
    margin: 60px auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 35px;
}

/* ===== CARDS ===== */
.card {
    background: #ffffff;
    border-radius: 28px;
    padding: 30px;
    box-shadow: 0 18px 40px rgba(0,0,0,0.08);

    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.card h3 {
    margin-top: 0;
    font-size: 22px;
     color: #555;
}

.card p {
    line-height: 1.7;
    color: #555;
    flex-grow: 1;
}

/* ===== BUTTON ===== */
.btn {
    display: inline-block;
    margin-top: 25px;
    padding: 12px 28px;
    background: #2f3e46;
    color: white;
    text-decoration: none;
    border-radius: 30px;
    font-weight: 600;
    width: fit-content;
}

.btn:hover {
    background: #1f2a30;
}

/* ===== FOOTER ===== */
footer {
    margin-top: auto;
    padding: 30px 0;
    text-align: center;
    color: #5a6b6f;
    background: rgba(255, 255, 255, 0.3);
    backdrop-filter: blur(10px);
    width: 100%;
}

</style>

</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">Tuition System</div>
    <nav>
        <a href="../auth/logout.php" class="logout">Logout</a>
    </nav>
</header>

<!-- MAIN CONTENT -->
<div class="main-content">

    <!-- HERO -->
    <section class="hero">
        <div>
            <h1>Student Dashboard</h1>
            <p>
                Students can book class, view their weekly schedules and make payments in this system. <br>
                Please use wisely and double check your information.
            </p>
            <a href="my_booking.php" class="btn">View Bookings</a>
        </div>

        <div class="hero-box">
            <h3>System Overview</h3>
            <p>
                ➡ Student can make bookings<br>
                ➡ View Schedules <br>
            </p>
        </div>
    </section>

    <!-- CARDS -->
    <section class="section">

        <div class="card">
            <h3>Book a Class</h3>
            <p>
                Book a one-by-one class with your preffered tutor, you can also book a private class with your friends.
            </p>
            <a href="book_class.php" class="btn">Book here!</a>
        </div>

        <div class="card">
            <h3>Weekly Schedule</h3>
            <p>
                View all scheduled classes in a clean timetable format for better
                planning.
            </p>
            <a href="calendar.php" class="btn">View</a>
        </div>

                <div class="card">
            <h3>View Bookings</h3>
            <p>
                See if your booking has been rejected or approved by the Admin. 
                You may proceed with your <b>payment</b> here. 
            </p>
            <a href="my_booking.php" class="btn">View</a>
        </div>


    </section>

</div>

<footer>
    © <?= date("Y"); ?> Tuition System · Students Dashboard
</footer>

</body>
</html>