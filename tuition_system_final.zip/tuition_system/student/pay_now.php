<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

$booking_id = $_GET['booking_id'];

$booking = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT b.booking_date, sub.subject_name
FROM booking b
JOIN class c ON b.class_id=c.class_id
JOIN subject sub ON c.subject_id=sub.subject_id
WHERE b.booking_id=$booking_id
"));

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $amount = 50;

    // Insert payment
    mysqli_query($conn,"
    INSERT INTO payment (booking_id,amount,payment_status,payment_date)
    VALUES ($booking_id,$amount,'Paid',NOW())
    ");

    // Update booking status
    mysqli_query($conn,"
    UPDATE booking 
    SET booking_status='Paid'
    WHERE booking_id=$booking_id
    ");

    header("Location: my_booking.php");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Pay Now</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

<style>
body{margin:0;font-family:Poppins,sans-serif;background:linear-gradient(180deg,#dbeff0,#eef7f7,#f7fcfc);}
.navbar{background:#2f5f63;padding:18px 40px;display:flex;justify-content:space-between;color:white;}
nav a{color:white;text-decoration:none;margin-left:20px;}
.container{max-width:500px;margin:100px auto;background:white;padding:40px;border-radius:26px;box-shadow:0 18px 40px rgba(0,0,0,.08);text-align:center;}
.btn{margin-top:20px;padding:10px 25px;border:none;border-radius:20px;font-weight:600;background:#2f5f63;color:white;cursor:pointer;}
.btn:hover{background:#1e4246;}
</style>
</head>

<body>

<header class="navbar">
<div>Tuition System</div>
<nav>
<a href="my_booking.php">Back</a>
<a href="../auth/logout.php">Logout</a>
</nav>
</header>

<div class="container">

<h2>Confirm Payment</h2>

<p><strong>Subject:</strong> <?= htmlspecialchars($booking['subject_name']) ?></p>
<p><strong>Date:</strong> <?= $booking['booking_date'] ?></p>
<p><strong>Amount:</strong> RM50</p>

<form method="POST">
<button class="btn">Confirm & Pay</button>
</form>

</div>

</body>
</html>
