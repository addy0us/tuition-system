<?php
session_start();
require_once "../config/db.php";

/* Student Only */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

/* Get student_id from user_id */
$user_id = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn,"SELECT student_id FROM student WHERE user_id=?");
mysqli_stmt_bind_param($stmt,"i",$user_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

if(!$student){
    die("Student profile not found.");
}

$student_id = $student['student_id'];

/* Fetch Classes */
$classes = mysqli_query($conn,"
SELECT 
    c.class_id,
    c.start_time,
    c.end_time,
    c.total_student,
    sub.subject_name,
    sub.subject_level,
    t.tutor_name
FROM class c
JOIN subject sub ON c.subject_id=sub.subject_id
JOIN tutor t ON c.tutor_id=t.tutor_id
ORDER BY sub.subject_name ASC
");

/* Booking Logic */
$error = "";

if(isset($_POST['book'])){

    $class_id = intval($_POST['class_id']);
    $date = $_POST['booking_date'];

    if($date < date('Y-m-d')){
        $error = "You cannot select past dates.";
    } else {

        // Insert booking (payment starts as Pending)
        mysqli_query($conn,"
        INSERT INTO booking
        (student_id,class_id,booking_date,booking_status,payment_status)
        VALUES
        ($student_id,$class_id,'$date','Pending','Pending')
        ");

        header("Location: my_booking.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Book Class</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
body{
margin:0;
font-family: 'Poppins',sans-serif;
background:linear-gradient(180deg,#dbeff0,#eef7f7,#f7fcfc);
}

.navbar{
background:#2f5f63;
padding:18px 40px;
display:flex;
justify-content:space-between;
align-items:center;
color:white;
font-weight:600;
}

nav a{
color:white;
text-decoration:none;
margin-left:20px;
}

.container{
max-width:700px;
margin:70px auto;
background:white;
padding:35px 40px;
border-radius:26px;
box-shadow:0 18px 40px rgba(0,0,0,.08);
}

label{
display:block;
margin-top:18px;
font-weight:600;
font-size: 15px;
color: #2f3e46;
margin-bottom: 8px;
}

select, input{
width:100%;
height:46px;
border-radius:12px;  /* Changed from 22px to 12px for less roundness */
border:1px solid #ddd;  /* Lighter border color */
padding:0 16px;
margin-top:8px;
font-family: 'Poppins', sans-serif;
font-size: 15px;
box-sizing: border-box;  /* Ensures padding doesn't affect width */
}

select{
cursor: pointer;
background-color: white;
-webkit-appearance: none;  /* Remove default arrow on Safari */
-moz-appearance: none;     /* Remove default arrow on Firefox */
appearance: none;
background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23333' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
background-repeat: no-repeat;
background-position: right 16px center;
padding-right: 40px;
}

input[type="date"]{
cursor: pointer;
}

/* Focus states for better UX */
select:focus, input:focus{
outline: none;
border-color: #2f5f63;
box-shadow: 0 0 0 3px rgba(47, 95, 99, 0.1);
}

.btn{
margin-top:30px;
padding:12px 30px;
border-radius:26px;
border:none;
background:#2f3e46;
color:white;
font-weight:600;
cursor:pointer;
font-family: 'Poppins', sans-serif;
font-size: 15px;
transition: all 0.3s ease;
}

.btn:hover{
background:#1f2a30;
transform: translateY(-2px);
box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.error{
background:#ffe6e6;
color:#c0392b;
padding:12px;
border-radius:14px;
margin-top:15px;
}

footer{
margin-top:80px;
padding:40px;
text-align:center;
color:#555;
}
</style>
<body>

<header class="navbar">
<div>Tuition System</div>
<nav>
<a href="dashboard.php">Back to Dashboard</a>
<a href="../auth/logout.php">Logout</a>
</nav>
</header>

<div class="container">

<h3>Book a Class</h3>
<p>Select a class. Your booking will be sent for admin approval.</p>

<form method="POST">

<label>Select Class</label>

<select name="class_id" required>
<option value="">Choose Class</option>

<?php while($c=mysqli_fetch_assoc($classes)): ?>
<option value="<?= $c['class_id'] ?>">

<?= htmlspecialchars($c['subject_name']) ?>
(<?= $c['subject_level'] ?>)
– Tutor <?= htmlspecialchars($c['tutor_name']) ?>
– <?= date("h:i A",strtotime($c['start_time'])) ?> to <?= date("h:i A",strtotime($c['end_time'])) ?>

</option>
<?php endwhile; ?>

</select>

<label>Select Date</label>
<input type="date" name="booking_date" min="<?= date('d-m-Y') ?>" required>

<?php if($error!=""): ?>
<div class="error"><?= $error ?></div>
<?php endif; ?>

<button name="book" class="btn">Submit Booking</button>

</form>

</div>

<footer>
© <?= date("Y") ?> Tuition System · Student Dashboard
</footer>

</body>
</html>
