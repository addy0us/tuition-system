<?php
echo password_hash("admin123", PASSWORD_DEFAULT);
?>

<?php
echo password_hash("student123", PASSWORD_DEFAULT);
?> 
