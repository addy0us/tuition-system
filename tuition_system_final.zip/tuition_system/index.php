<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "tuition_system";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tuition System</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #ffe0f0, #fff5fa);
            min-height: 100vh;
        }
        .hero {
            height: 100vh;
        }
        .card {
            border-radius: 20px;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
            border-radius: 30px;
            padding: 10px 30px;
        }
        .btn-pink:hover {
            background-color: #ff85c2;
            color: white;
        }
        .text-pink {
            color: #ff69b4;
        }
    </style>
</head>

<body>

<div class="container hero d-flex align-items-center">
    <div class="row w-100 align-items-center">

        <!-- LEFT TEXT -->
        <div class="col-md-6">
            <h1 class="fw-bold mb-3">
                Welcome to <span class="text-pink">Tuition System</span> 💖
            </h1>

            <p class="text-muted mb-4">
                A simple and user-friendly platform to manage tuition classes,
                bookings, and payments.  
                Designed with love 💕 for students and administrators.
            </p>

            <a href="auth/login.php" class="btn btn-pink me-3">
                Login
            </a>

            <a href="#features" class="btn btn-outline-secondary">
                Learn More
            </a>
        </div>

        <!-- RIGHT CARD -->
        <div class="col-md-6 d-none d-md-block">
            <div class="card shadow p-4">
                <h5 class="fw-bold text-pink">✨ System Features</h5>
                <ul class="mt-3">
                    <li>👩‍💼 Admin subject & class management</li>
                    <li>🎓 Student class booking</li>
                    <li>💳 Secure payment module</li>
                    <li>🔐 Login & role-based access</li>
                    <li>📊 Database-driven system</li>
                </ul>
            </div>
        </div>

    </div>
</div>

<!-- FEATURES SECTION -->
<div id="features" class="container my-5">
    <h3 class="text-center fw-bold mb-4 text-pink">Why Choose Our System?</h3>

    <div class="row text-center">
        <div class="col-md-4">
            <div class="card shadow p-3 mb-3">
                <h5>🌸 Easy to Use</h5>
                <p class="text-muted">
                    Clean interface designed for simplicity and clarity.
                </p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow p-3 mb-3">
                <h5>💖 Student Friendly</h5>
                <p class="text-muted">
                    Students can easily book classes and make payments.
                </p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow p-3 mb-3">
                <h5>📚 Admin Control</h5>
                <p class="text-muted">
                    Manage subjects, classes, and records efficiently.
                </p>
            </div>
        </div>
    </div>
</div>

<!-- FOOTER -->
<footer class="text-center py-3 text-muted">
    © <?= date("Y") ?> Tuition System • 
</footer>

</body>
</html>
